/** Mock controller capability advertisement. Physical channel characteristics are advertised per channel. */
export type CapabilityKind = 'actuator' | 'sensor';
export type CapabilityValueType = 'binary' | 'analog';
export type ControlPolicy = 'manual_binary' | 'binary_curve' | 'analog_curve' | 'threshold_rules' | 'periodic_pulse';

export interface CapabilityChannel {
    /** Stable hardware channel identifier, unique within its parent capability. */
    id: string;
    label: string;
    valueType: CapabilityValueType;
    unit?: string;
    min?: number;
    max?: number;
    supportedPolicies: ControlPolicy[];
}

export interface ControllerCapability {
    /** Stable hardware resource / capability identifier. */
    id: string;
    name: string;
    kind: CapabilityKind;
    channels: CapabilityChannel[];
    icon: string;
}

const analogPolicies: ControlPolicy[] = ['analog_curve'];
const binaryPolicies: ControlPolicy[] = ['manual_binary', 'binary_curve', 'threshold_rules', 'periodic_pulse'];

export const MOCK_CONTROLLER_CAPABILITIES: ControllerCapability[] = [
    {
        id: 'analog_channel_1', name: 'Lighting Fixture', kind: 'actuator', icon: 'sunny-outline',
        channels: [
            { id: 'white', label: 'White', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
            { id: 'red', label: 'Red', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
            { id: 'green', label: 'Green', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
            { id: 'blue', label: 'Blue', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
        ],
    },
    {
        id: 'analog_channel_2', name: 'Wavemaker', kind: 'actuator', icon: 'water-outline',
        channels: [
            { id: 'pump_speed', label: 'Pump Speed', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
            { id: 'oscillation', label: 'Oscillation', valueType: 'binary', supportedPolicies: binaryPolicies },
        ],
    },
        {
        id: 'analog_channel_3', name: 'Fountain', kind: 'actuator', icon: 'sunny-outline',
        channels: [
            { id: 'xaxis', label: 'X-Axis', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
            { id: 'yaxis', label: 'Y-Axis', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
            { id: 'zaxis', label: 'Z-Axis', valueType: 'analog', unit: '%', min: 0, max: 100, supportedPolicies: analogPolicies },
            { id: 'flow', label: 'Flow', valueType: 'binary', supportedPolicies: binaryPolicies },
        ],
    },
    ...[1, 2, 3, 4].map((n) => ({
        id: `relay_channel_${n}`, name: `Relay ${n}`, kind: 'actuator' as const, icon: 'cloud-outline',
        channels: [{ id: 'output', label: 'Relay Output', valueType: 'binary' as const, supportedPolicies: binaryPolicies }],
    })),
    { id: 'sensor_channel_1', name: 'Temperature', kind: 'sensor', icon: 'thermometer-outline', channels: [{ id: 'value', label: 'Temperature', valueType: 'analog', unit: '°C', min: -10, max: 60, supportedPolicies: [] }] },
    { id: 'sensor_channel_2', name: 'pH Sensor', kind: 'sensor', icon: 'flask-outline', channels: [{ id: 'value', label: 'pH', valueType: 'analog', unit: 'pH', min: 0, max: 14, supportedPolicies: [] }] },
];

/** Legacy key map retained for migration of existing single-channel assignments. */
export const DEFAULT_CONTROL_POLICIES: Record<string, ControlPolicy> = {
    'analog_channel_1:white': 'analog_curve',
    'analog_channel_1:red': 'analog_curve',
    'analog_channel_1:green': 'analog_curve',
    'analog_channel_1:blue': 'analog_curve',
    'analog_channel_2:pump_speed': 'analog_curve',
    'analog_channel_2:oscillation': 'manual_binary',
    'relay_channel_1:output': 'binary_curve',
};
export const CONTROL_POLICY_STORAGE_KEY = 'prakiva.dashboard.channel-policies.v2';
export const POLICY_LABELS: Record<ControlPolicy, string> = {
    manual_binary: 'Manual ON/OFF', binary_curve: 'Periodic ON/OFF', analog_curve: 'Analogue curve',
    threshold_rules: 'Sensor thresholds', periodic_pulse: 'Periodic pulse',
};
export const channelPolicyKey = (capabilityId: string, channelId: string) => `${capabilityId}:${channelId}`;
