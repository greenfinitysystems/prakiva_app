import type { SavedController } from '../models/saved-controller';
import type { ControlConfigurationDocument } from './control-configuration-store';

/** Local synchronisation bookkeeping. Controller timestamps are always supplied by firmware. */
export const CONFIGURATION_SYNC_STATE_KEY = 'prakiva.configuration.sync-state.v2';
export const MOCK_CONTROLLER_CONFIGURATION_PREFIX = 'prakiva.mock-controller.configuration.';

export type ConfigurationSyncPhase = 'idle' | 'checking' | 'applying' | 'failed' | 'conflict';
export type ConfigurationSyncStatus = 'up-to-date' | 'apply-pending' | 'not-configured' | 'applying' | 'checking' | 'failed' | 'conflict';

export interface ControllerConfigurationMetadata {
    configuration_exists: boolean;
    configuration_updated_at: string | null;
    clock_valid: boolean;
}

export interface ControllerSyncRecord {
    controllerId: string;
    applyPending: boolean;
    phase: ConfigurationSyncPhase;
    /** Last controller timestamp this phone successfully synchronised against. */
    lastSyncedControllerAt: string | null;
    /** Most recently observed controller timestamp. */
    controllerUpdatedAt: string | null;
    lastAppliedAt: string | null;
    lastError?: string;
    adapter: 'mock' | 'controller';
}

export type ReconcileResult = 'in-sync' | 'controller-updated' | 'no-controller-configuration' | 'conflict';

interface MockControllerConfiguration {
    metadata: ControllerConfigurationMetadata;
    document: ControlConfigurationDocument;
}

function readRecords(): Record<string, ControllerSyncRecord> {
    try {
        const raw = localStorage.getItem(CONFIGURATION_SYNC_STATE_KEY);
        if (!raw) return {};
        const parsed: unknown = JSON.parse(raw);
        return typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)
            ? parsed as Record<string, ControllerSyncRecord> : {};
    } catch { return {}; }
}

function writeRecord(record: ControllerSyncRecord): void {
    const records = readRecords();
    records[record.controllerId] = record;
    localStorage.setItem(CONFIGURATION_SYNC_STATE_KEY, JSON.stringify(records));
    if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('prakiva:configuration-sync-state-changed', { detail: { controllerId: record.controllerId } }));
    }
}

export function getControllerSyncRecord(controllerId: string): ControllerSyncRecord {
    const stored = readRecords()[controllerId];
    if (!stored) return {
        controllerId, applyPending: false, phase: 'idle', lastSyncedControllerAt: null,
        controllerUpdatedAt: null, lastAppliedAt: null, adapter: 'mock',
    };
    if (stored.phase === 'applying' || stored.phase === 'checking') {
        const interrupted: ControllerSyncRecord = {
            ...stored, phase: 'failed',
            lastError: 'The previous synchronisation operation was interrupted before acknowledgement.',
        };
        writeRecord(interrupted);
        return interrupted;
    }
    return stored;
}

export function markLocalConfigurationPending(controllerId: string): ControllerSyncRecord {
    const previous = getControllerSyncRecord(controllerId);
    const next = { ...previous, applyPending: true, phase: 'idle' as const, lastError: undefined };
    writeRecord(next);
    return next;
}

export function getConfigurationSyncStatus(
    record: ControllerSyncRecord,
    metadata?: ControllerConfigurationMetadata | null,
): ConfigurationSyncStatus {
    if (record.phase === 'applying') return 'applying';
    if (record.phase === 'checking') return 'checking';
    if (record.phase === 'failed') return 'failed';
    if (record.phase === 'conflict') return 'conflict';
    if (record.applyPending) return 'apply-pending';
    if (metadata && !metadata.configuration_exists) return 'not-configured';
    if (record.lastSyncedControllerAt && metadata?.configuration_updated_at === record.lastSyncedControllerAt) return 'up-to-date';
    return 'not-configured';
}

function readMockController(controllerId: string): MockControllerConfiguration | null {
    try {
        const raw = localStorage.getItem(`${MOCK_CONTROLLER_CONFIGURATION_PREFIX}${controllerId}`);
        if (!raw) return null;
        const value = JSON.parse(raw) as MockControllerConfiguration;
        if (!value || typeof value !== 'object' || !value.metadata || !value.document) return null;
        return value;
    } catch { return null; }
}

function writeMockController(controllerId: string, value: MockControllerConfiguration): void {
    localStorage.setItem(`${MOCK_CONTROLLER_CONFIGURATION_PREFIX}${controllerId}`, JSON.stringify(value));
}

/** UI-only controller metadata read. This local mock is replaced by get_configuration_status firmware API. */
export async function getControllerConfigurationMetadataWithMockAdapter(
    controller: SavedController,
): Promise<ControllerConfigurationMetadata> {
    await new Promise(resolve => setTimeout(resolve, 180));
    return readMockController(controller.deviceId)?.metadata ?? {
        configuration_exists: false, configuration_updated_at: null, clock_valid: true,
    };
}

function isUtcSecondTimestamp(value: unknown): value is string {
    return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(value) && !Number.isNaN(Date.parse(value));
}

function validateControllerTimestamp(metadata: ControllerConfigurationMetadata): void {
    if (typeof metadata.configuration_exists !== 'boolean' || typeof metadata.clock_valid !== 'boolean') {
        throw new Error('Controller returned invalid configuration metadata.');
    }
    if (metadata.configuration_exists) {
        if (!isUtcSecondTimestamp(metadata.configuration_updated_at)) {
            throw new Error('Controller configuration timestamp is missing or invalid.');
        }
    } else if (metadata.configuration_updated_at !== null) {
        throw new Error('Controller reported no configuration but returned a configuration timestamp.');
    }
    if (!metadata.clock_valid) throw new Error('The controller clock is not valid. Correct the controller time before synchronising configuration.');
}

/**
 * Reconcile this phone against controller metadata. If only the controller has
 * changed, download its configuration. If this phone also has pending edits,
 * report a conflict and leave both copies untouched.
 */
export async function reconcileControllerConfigurationWithMockAdapter(
    controller: SavedController,
    localDocument: ControlConfigurationDocument,
    localHasUnsavedChanges: boolean,
    replaceLocalDocument: (document: ControlConfigurationDocument) => void,
): Promise<{ result: ReconcileResult; record: ControllerSyncRecord; metadata: ControllerConfigurationMetadata }> {
    const previous = getControllerSyncRecord(controller.deviceId);
    writeRecord({ ...previous, phase: 'checking', lastError: undefined });
    try {
        const metadata = await getControllerConfigurationMetadataWithMockAdapter(controller);
        validateControllerTimestamp(metadata);
        const mock = readMockController(controller.deviceId);
        let result: ReconcileResult;
        let next: ControllerSyncRecord;

        if (!metadata.configuration_exists) {
            result = 'no-controller-configuration';
            next = { ...previous, phase: 'idle', controllerUpdatedAt: null, lastError: undefined };
        } else if (!previous.lastSyncedControllerAt) {
            // First connection on this phone. Prefer the controller only when this phone has
            // no meaningful local configuration; otherwise preserve both copies for a choice.
            const hasLocalContent = Object.values(localDocument.controls).some(control =>
                Object.keys(control.channelPolicies).length > 0 || control.curves.length > 0 ||
                Object.keys(control.inlineConfigurations).length > 0 ||
                Object.values(control.profilesByControlId ?? {}).some(items => items.length > 0) ||
                control.workspace !== null,
            ) || Object.keys(localDocument.presentation.capabilityLabels).length > 0 ||
                Object.keys(localDocument.presentation.channelColors).length > 0;
            if (hasLocalContent || localHasUnsavedChanges) {
                result = 'conflict';
                next = { ...previous, phase: 'conflict', controllerUpdatedAt: metadata.configuration_updated_at,
                    lastError: 'This phone has a local configuration and the controller already has a configuration.' };
            } else {
                if (!mock?.document) throw new Error('Controller reports a configuration, but the mock adapter has no configuration payload.');
                replaceLocalDocument(mock.document);
                result = 'controller-updated';
                next = { ...previous, applyPending: false, phase: 'idle', lastSyncedControllerAt: metadata.configuration_updated_at,
                    controllerUpdatedAt: metadata.configuration_updated_at, lastAppliedAt: null, lastError: undefined };
            }
        } else if (metadata.configuration_updated_at === previous.lastSyncedControllerAt) {
            result = 'in-sync';
            next = { ...previous, phase: 'idle', controllerUpdatedAt: metadata.configuration_updated_at, lastError: undefined };
        } else if (previous.applyPending || localHasUnsavedChanges) {
            result = 'conflict';
            next = { ...previous, phase: 'conflict', controllerUpdatedAt: metadata.configuration_updated_at,
                lastError: 'Both this phone and the controller have changed since the last synchronisation.' };
        } else {
            if (!mock?.document) throw new Error('Controller configuration payload could not be retrieved.');
            replaceLocalDocument(mock.document);
            result = 'controller-updated';
            next = { ...previous, applyPending: false, phase: 'idle', lastSyncedControllerAt: metadata.configuration_updated_at,
                controllerUpdatedAt: metadata.configuration_updated_at, lastError: undefined };
        }
        writeRecord(next);
        return { result, record: next, metadata };
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const failed = { ...getControllerSyncRecord(controller.deviceId), phase: 'failed' as const, lastError: message };
        writeRecord(failed);
        throw error;
    }
}

export function markConfigurationApplying(controllerId: string): ControllerSyncRecord {
    const previous = getControllerSyncRecord(controllerId);
    const next = { ...previous, phase: 'applying' as const, lastError: undefined };
    writeRecord(next);
    return next;
}

export interface MockApplyResult { requestId: string; configurationUpdatedAt: string; mode: 'mock'; }

/** UI-only adapter: simulates a hardware-issued UTC timestamp and stores a mock controller copy locally. */
export async function applyConfigurationWithMockAdapter(
    controller: SavedController,
    document: ControlConfigurationDocument,
): Promise<MockApplyResult> {
    if (!controller.deviceId) throw new Error('Controller identity is missing.');
    if (document.format !== 'prakiva-control-configuration' || !document.controls || typeof document.controls !== 'object') {
        throw new Error('The saved configuration has an invalid structure.');
    }
    await new Promise(resolve => setTimeout(resolve, 650));
    // In the real implementation this value is generated by the ESP32 RTC after persistence succeeds.
    const configurationUpdatedAt = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
    const metadata: ControllerConfigurationMetadata = {
        configuration_exists: true, configuration_updated_at: configurationUpdatedAt, clock_valid: true,
    };
    writeMockController(controller.deviceId, { metadata, document: JSON.parse(JSON.stringify(document)) as ControlConfigurationDocument });
    return { requestId: `mock-apply-${controller.deviceId.slice(0, 8)}-${Date.now()}`, configurationUpdatedAt, mode: 'mock' };
}

export function markConfigurationSynchronized(controllerId: string, controllerTimestamp: string | null): ControllerSyncRecord {
    const previous = getControllerSyncRecord(controllerId);
    const next: ControllerSyncRecord = {
        ...previous,
        applyPending: false,
        phase: 'idle',
        lastSyncedControllerAt: controllerTimestamp,
        controllerUpdatedAt: controllerTimestamp,
        lastError: undefined,
        adapter: 'controller',
    };
    writeRecord(next);
    return next;
}

export function markConfigurationApplied(controllerId: string, controllerTimestamp: string, adapter: 'mock' | 'controller' = 'controller'): ControllerSyncRecord {
    const next: ControllerSyncRecord = {
        ...getControllerSyncRecord(controllerId), applyPending: false, phase: 'idle',
        lastSyncedControllerAt: controllerTimestamp, controllerUpdatedAt: controllerTimestamp,
        lastAppliedAt: controllerTimestamp, lastError: undefined, adapter,
    };
    writeRecord(next);
    return next;
}

export function markConfigurationApplyFailed(controllerId: string, error: string): ControllerSyncRecord {
    const next = { ...getControllerSyncRecord(controllerId), phase: 'failed' as const, lastError: error };
    writeRecord(next);
    return next;
}

/** Explicitly choose the controller copy when both sides changed. */
export function useControllerConfigurationWithMockAdapter(
    controllerId: string,
    replaceLocalDocument: (document: ControlConfigurationDocument) => void,
): ControllerSyncRecord {
    const mock = readMockController(controllerId);
    if (!mock?.metadata.configuration_exists) throw new Error('The controller has no saved configuration to retrieve.');
    replaceLocalDocument(mock.document);
    const previous = getControllerSyncRecord(controllerId);
    const timestamp = mock.metadata.configuration_updated_at;
    const next: ControllerSyncRecord = {
        ...previous, applyPending: false, phase: 'idle', lastSyncedControllerAt: timestamp,
        controllerUpdatedAt: timestamp, lastError: undefined,
    };
    writeRecord(next);
    return next;
}
