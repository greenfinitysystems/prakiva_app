import { useEffect, useState } from 'react';
import { IonButton, IonButtons, IonContent, IonHeader, IonIcon, IonItem, IonLabel, IonList, IonPage, IonText, IonTitle, IonToolbar } from '@ionic/react';
import { homeOutline, arrowBackOutline } from 'ionicons/icons';
import { useLocation, useNavigate } from 'react-router-dom';
import type { SavedController } from '../models/saved-controller';
import { ControllerSynchronizationStore, type ControllerSynchronizationSnapshot } from '../services/controller-synchronization-store';

interface InfoState { controller?: SavedController; deviceInfo?: Record<string, unknown> }

const ControllerInfo: React.FC = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const state = (location.state as InfoState | null) ?? {};
    const controller = state.controller;
    const deviceInfo = state.deviceInfo ?? {};
    const [snapshot, setSnapshot] = useState<ControllerSynchronizationSnapshot | null>(null);

    useEffect(() => {
        let active = true;
        if (controller) {
            void ControllerSynchronizationStore.load(controller.deviceId).then(value => {
                if (active) setSnapshot(value);
            });
        }
        return () => { active = false; };
    }, [controller?.deviceId]);

    if (!controller) return <IonPage><IonContent className="ion-padding"><p>Controller context is missing.</p><IonButton onClick={() => navigate('/home', { replace: true })}>Go to Home</IonButton></IonContent></IonPage>;
    const fields: Array<[string, unknown]> = [
        ['Controller name', controller.name],
        ['Device ID', controller.deviceId],
        ['Address', `${controller.address}:${controller.httpPort}`],
        ['Product', snapshot?.capabilities.controller.product ?? controller.product],
        ['Hardware family', snapshot?.capabilities.controller.hardware_family ?? controller.hardwareFamily],
        ['Firmware version', snapshot?.capabilities.controller.firmware_version ?? controller.firmwareVersion],
        ['Flash', snapshot ? `${snapshot.capabilities.controller.flash_mb} MB` : 'Not synchronized'],
        ['PSRAM', snapshot ? `${snapshot.capabilities.controller.psram_mb} MB` : 'Not synchronized'],
        ['Protocol version', deviceInfo.protocol_version ?? deviceInfo.protocolVersion ?? '0.1'],
        ['Configuration storage', snapshot?.configuration.storage ?? 'Not synchronized'],
        ['Configuration saved', snapshot ? (snapshot.configuration.configuration_exists ? 'Yes' : 'No') : 'Not synchronized'],
        ['Configuration timestamp', snapshot?.configuration.configuration_exists ? String(snapshot.configuration.configuration_timestamp) : 'Not available'],
    ];
    return <IonPage>
        <IonHeader><IonToolbar>
            <IonButtons slot="start"><IonButton fill="clear" aria-label="Home" onClick={() => navigate('/home')}><IonIcon icon={homeOutline} /></IonButton></IonButtons>
            <IonTitle>Controller Info</IonTitle>
            <IonButtons slot="end"><IonButton fill="clear" aria-label="Back to controller" onClick={() => navigate('/controller-dashboard', { state: { controller } })}><IonIcon icon={arrowBackOutline} /></IonButton></IonButtons>
        </IonToolbar></IonHeader>
        <IonContent className="prakiva-home ion-padding">
            <IonList inset>
                {fields.map(([label, value]) => <IonItem key={label}><IonLabel className="ion-text-wrap"><p>{label}</p><h2>{value == null || value === '' ? 'Not available' : String(value)}</h2></IonLabel></IonItem>)}
            </IonList>
            <h2 className="ion-padding-start">Controller interfaces</h2>
            {snapshot ? <IonList inset>{snapshot.capabilities.interfaces.map(item => <IonItem key={item}><IonLabel>{item}</IonLabel></IonItem>)}</IonList> : <IonText color="medium"><p className="ion-padding-start">Sign in to retrieve the controller capability document.</p></IonText>}
            <h2 className="ion-padding-start">Supported API operations</h2>
            {snapshot ? <IonList inset>{Object.entries(snapshot.capabilities.operations).map(([operation, supported]) => <IonItem key={operation}><IonLabel>{operation}</IonLabel><IonText color={supported ? 'success' : 'medium'}>{supported ? 'Supported' : 'Not supported'}</IonText></IonItem>)}</IonList> : null}
        </IonContent>
    </IonPage>;
};
export default ControllerInfo;
